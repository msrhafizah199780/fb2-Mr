# Fb2
Hack Facebook <br>
$pkg update && pkg upgrade - y <br>


$pkg install git <br>
$pkg install python2 <br>
$git clone https://github.com/Systemvuln/Fb2.git <br>
$cd Fb2 <br>
$python2 retasfb.py <br>


![IMG_20190825_171427](https://user-images.githubusercontent.com/44978328/63648595-357fd700-c75c-11e9-9bd5-6f64da0ba3e2.jpg)

![IMG_20190825_173242](https://user-images.githubusercontent.com/44978328/63648760-8e506f00-c75e-11e9-8fbd-10cc70cc00c8.jpg)


